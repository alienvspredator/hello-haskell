import Test.Hspec
import Test.QuickCheck
import Control.Exception (evaluate)

import           BinTree
import           Nat

binTreeTestDepth :: Bool
binTreeTestDepth =
    Nat.natToInteger
            (depth
                (BinTree
                    ( BinTree (BinTree (List 5, List 9), List 9)
                    , BinTree
                        ( BinTree (List 1, List 9)
                        , BinTree
                            ( BinTree (List 5, List 9)
                            , BinTree (BinTree (List 9, List 3), List 4)
                            )
                        )
                    )
                )
            )
        == 6

main :: IO ()
main = hspec $ do
    print ("binTreeTestDepth" ++ (show binTreeTestDepth))
    print "Test passed"
